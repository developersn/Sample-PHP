<?php
session_start();



if(isset($_SESSION['au'])){


                   $au=$_SESSION['au'];
                   $amount= $_SESSION['amount'];
                   $order= $_SESSION['order'];

                                    $bank_return = $_POST + $_GET ;
                                    $data_string = json_encode(array (
                                    'pin' => "Sk_21adceffcfceb",
                                    'price' =>  $amount,
                                    'order_id' => $order,
                                    'au' =>  $au,
                                    'bank_return' =>$bank_return,
                                    ));

                                    $ch = curl_init('https://developerapi.net/api/v1/verify');
                                    curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
                                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                                    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                                    'Content-Type: application/json',
                                    'Content-Length: ' . strlen($data_string))
                                    );
                                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                                    curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, 20);
                                    $result = curl_exec($ch);
                                    curl_close($ch);
                                    $json = json_decode($result,true);
                                 

                 if(!empty($json['result']) AND $json['result'] == 1)

                    { 
                         unset($_SESSION['au']);
                         unset($_SESSION['amount']); 
                         unset($_SESSION['order']); 
                       // اگر پرداخت موفق بود در این قسمت میتوانید عملیات یا  پیام ها مورد نظر خود را وارد نمایید.
                    echo "Payment operation successfully completed";          
                    }


                    else
                    {
                       unset($_SESSION['au']); 
                        unset($_SESSION['amount']); 
                         unset($_SESSION['order']); 
                        echo "پرداخت با خطا مواجه شد";
                        
                    }
   
   }


    
?>