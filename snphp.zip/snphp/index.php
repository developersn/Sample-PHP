<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>php</title>


</head>
<body>

<div id="container">
	

	<div id="body" style="direction: rtl;">




<h2>ارسال مقادیر </h2>

<form action="snrequest.php"  method="post">
مبلغ:<br>
<input type="text" name="amount"><br>
شماره فاکتور:<br>
<input type="text" name="order" ><br><br>
<input type="submit" value="Send">

</form>

	</div>

</div>

</body>
</html>